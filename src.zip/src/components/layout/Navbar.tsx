// src/components/layout/Navbar.tsx (Updated with Auth)
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Navbar as HeroNavbar,
  NavbarBrand,
  NavbarContent,
  NavbarItem,
  NavbarMenuToggle,
  NavbarMenu,
  NavbarMenuItem,
  Button,
  Dropdown,
  DropdownTrigger,
  DropdownMenu,
  DropdownItem,
  Avatar,
  Input,
} from '@heroui/react';
import { SearchIcon, UserIcon } from '../Icons';
import { useAuth } from '../../contexts/AuthContext';
import ThemeSwitcher from '../ThemeSwitcher';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { isAuthenticated, user, logout } = useAuth();

  const menuItems = [
    { label: 'Home', path: '/' },
    { label: 'Events', path: '/events' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <HeroNavbar
      isBordered
      isMenuOpen={isMenuOpen}
      onMenuOpenChange={setIsMenuOpen}
      maxWidth="xl"
      
    >
      {/* Mobile Menu Toggle */}
      <NavbarContent className="sm:hidden" justify="start">
        <NavbarMenuToggle
          aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
        />
      </NavbarContent>

      {/* Logo/Brand - Mobile */}
      <NavbarContent className="sm:hidden pr-3" justify="center">
        <NavbarBrand>
          <Link to="/" className="font-bold text-xl text-primary">
            EventHub
          </Link>
        </NavbarBrand>
      </NavbarContent>

      {/* Logo/Brand - Desktop */}
      <NavbarContent className="hidden sm:flex gap-4" justify="start">
        <NavbarBrand>
          <Link to="/" className="font-bold text-xl text-primary">
            EventHub
          </Link>
        </NavbarBrand>
      </NavbarContent>

      {/* Desktop Navigation Links */}
      <NavbarContent className="hidden sm:flex gap-8" justify="center">
        {menuItems.map((item) => (
          <NavbarItem key={item.path}>
            <Link
              to={item.path}
              className="text-foreground hover:text-primary transition-colors"
            >
              {item.label}
            </Link>
          </NavbarItem>
        ))}
      </NavbarContent>

      {/* Right Side Content */}

      <ThemeSwitcher />
      <NavbarContent justify="end">
        {/* Search Bar - Desktop */}
        <NavbarItem className="hidden lg:flex">
          <Input
            classNames={{
              base: 'max-w-full sm:max-w-[200px] h-10',
              mainWrapper: 'h-full',
              input: 'text-small',
              inputWrapper: 'h-full font-normal text-default-500',
            }}
            placeholder="Search events..."
            size="sm"
            startContent={<SearchIcon />}
            type="search"
          />
        </NavbarItem>

        {/* Authentication Buttons or User Menu */}
        {!isAuthenticated ? (
          <>
            <NavbarItem className="hidden sm:flex">
              <Button
                as={Link}
                to="/login"
                variant="light"
                color="primary"
              >
                Login
              </Button>
            </NavbarItem>
            <NavbarItem>
              <Button
                as={Link}
                to="/register"
                color="primary"
                variant="solid"
              >
                Sign Up
              </Button>
            </NavbarItem>
          </>
        ) : (
          <NavbarItem>
            <Dropdown placement="bottom-end">
              <DropdownTrigger>
                <Avatar
                  isBordered
                  as="button"
                  className="transition-transform"
                  color="primary"
                  name={user?.name || 'User'}
                  size="sm"
                  icon={<UserIcon />}
                />
              </DropdownTrigger>
              <DropdownMenu aria-label="Profile Actions" variant="flat">
                <DropdownItem key="profile" className="h-14 gap-2">
                  <p className="font-semibold">Signed in as</p>
                  <p className="font-semibold">{user?.email}</p>
                </DropdownItem>
                <DropdownItem
                  key="dashboard"
                  onClick={() => navigate('/dashboard')}
                >
                  Dashboard
                </DropdownItem>
                <DropdownItem
                  key="my-tickets"
                  onClick={() => navigate('/my-tickets')}
                >
                  My Tickets
                </DropdownItem>
                <DropdownItem
                  key="settings"
                  onClick={() => navigate('/settings')}
                >
                  Settings
                </DropdownItem>
                <DropdownItem
                  key="logout"
                  color="danger"
                  onClick={handleLogout}
                >
                  Log Out
                </DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </NavbarItem>
        )}
      </NavbarContent>

      {/* Mobile Menu */}
      <NavbarMenu>
        {/* Search Bar - Mobile */}
        <NavbarMenuItem className="mb-4">
          <Input
            classNames={{
              base: 'max-w-full',
              mainWrapper: 'h-full',
              input: 'text-small',
              inputWrapper: 'h-full font-normal text-default-500',
            }}
            placeholder="Search events..."
            size="lg"
            startContent={<SearchIcon />}
            type="search"
          />
        </NavbarMenuItem>

        {menuItems.map((item, index) => (
          <NavbarMenuItem key={`${item.path}-${index}`}>
            <Link
              to={item.path}
              className="w-full text-lg"
              onClick={() => setIsMenuOpen(false)}
            >
              {item.label}
            </Link>
          </NavbarMenuItem>
        ))}

        {!isAuthenticated ? (
          <>
            <NavbarMenuItem>
              <Link
                to="/login"
                className="w-full text-lg text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Login
              </Link>
            </NavbarMenuItem>
            <NavbarMenuItem>
              <Link
                to="/register"
                className="w-full text-lg font-semibold text-primary"
                onClick={() => setIsMenuOpen(false)}
              >
                Sign Up
              </Link>
            </NavbarMenuItem>
          </>
        ) : (
          <>
            <NavbarMenuItem>
              <Link
                to="/dashboard"
                className="w-full text-lg"
                onClick={() => setIsMenuOpen(false)}
              >
                Dashboard
              </Link>
            </NavbarMenuItem>
            <NavbarMenuItem>
              <Link
                to="/my-tickets"
                className="w-full text-lg"
                onClick={() => setIsMenuOpen(false)}
              >
                My Tickets
              </Link>
            </NavbarMenuItem>
            <NavbarMenuItem>
              <Link
                to="/settings"
                className="w-full text-lg"
                onClick={() => setIsMenuOpen(false)}
              >
                Settings
              </Link>
            </NavbarMenuItem>
            <NavbarMenuItem>
              <button
                onClick={() => {
                  handleLogout();
                  setIsMenuOpen(false);
                }}
                className="w-full text-lg text-left text-danger"
              >
                Log Out
              </button>
            </NavbarMenuItem>
          </>
        )}
      </NavbarMenu>
    </HeroNavbar>
  );
};

export default Navbar;