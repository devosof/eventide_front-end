import {Event} from '../types/event.types';

export const mockEvents: Event[] = [
    {
        id: "1",
        title: "Tech Conference 2025",
        description: "Join us for the biggest tech conference featuring industry leaders and innovative workshops. Topics include AI, Web Development, and Cloud Computing.",
        date: new Date("2025-11-15T09:00:00"),
        location: "Convention Center, New York",
        organizerId: "org1",
        organizationId: "techorg1",
        price: 299.99,
        capacity: 1000,
        imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87",
        categories: ["Technology", "Conference"],
        tags: ["tech", "innovation", "networking"],
        schedule: [
            {
                time: "09:00 AM",
                activity: "Registration & Breakfast"
            },
            {
                time: "10:00 AM",
                activity: "Keynote Speech"
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break"
            }
        ]
    },
    {
        id: "2",
        title: "Summer Music Festival",
        description: "Three days of non-stop music featuring top artists from around the world. Experience amazing performances across multiple stages.",
        date: new Date("2025-07-20T14:00:00"),
        location: "Central Park, New York",
        organizerId: "org2",
        organizationId: "musicorg1",
        price: 150.00,
        capacity: 5000,
        imageUrl: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea",
        categories: ["Music", "Festival"],
        tags: ["music", "outdoor", "summer"],
        schedule: [
            {
                time: "2:00 PM",
                activity: "Gates Open"
            },
            {
                time: "3:00 PM",
                activity: "First Performance"
            },
            {
                time: "10:00 PM",
                activity: "Headliner"
            }
        ]
    },
    {
        id: "3",
        title: "Food & Wine Expo",
        description: "Discover culinary delights from top chefs and wine experts. Includes tastings, cooking demonstrations, and wine pairing sessions.",
        date: new Date("2025-09-05T11:00:00"),
        location: "Grand Hotel, Chicago",
        organizerId: "org3",
        organizationId: "foodorg1",
        price: 75.00,
        capacity: 500,
        imageUrl: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0",
        categories: ["Food", "Wine", "Expo"],
        tags: ["culinary", "wine", "gourmet"],
        schedule: [
            {
                time: "11:00 AM",
                activity: "Welcome Reception"
            },
            {
                time: "1:00 PM",
                activity: "Wine Tasting"
            },
            {
                time: "3:00 PM",
                activity: "Cooking Demo"
            }
        ]
    },
    {
        id: "4",
        title: "Business Leadership Summit",
        description: "Connect with industry leaders and learn about the latest business strategies and leadership techniques.",
        date: new Date("2025-10-10T08:30:00"),
        location: "Business Center, San Francisco",
        organizerId: "org4",
        organizationId: "bizorg1",
        price: 499.99,
        capacity: 300,
        imageUrl: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0",
        categories: ["Business", "Leadership"],
        tags: ["business", "leadership", "networking"],
        schedule: [
            {
                time: "8:30 AM",
                activity: "Registration"
            },
            {
                time: "9:00 AM",
                activity: "Opening Remarks"
            },
            {
                time: "5:00 PM",
                activity: "Networking Event"
            }
        ]
    },
    {
        id: "5",
        title: "Fitness & Wellness Expo",
        description: "A day dedicated to health and wellness featuring fitness classes, nutrition workshops, and wellness vendors.",
        date: new Date("2025-08-15T09:00:00"),
        location: "Sports Complex, Los Angeles",
        organizerId: "org5",
        organizationId: "fitnessorg1",
        price: 45.00,
        capacity: 800,
        imageUrl: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438",
        categories: ["Fitness", "Wellness"],
        tags: ["fitness", "health", "wellness"],
        schedule: [
            {
                time: "9:00 AM",
                activity: "Morning Yoga"
            },
            {
                time: "11:00 AM",
                activity: "Nutrition Talk"
            },
            {
                time: "2:00 PM",
                activity: "HIIT Workshop"
            }
        ]
    }
];



export const mockOrganizations = [
  {
    id: "techorg1",
    name: "Tech Events International",
    description: "Leading technology events organizer",
    logo: "https://example.com/logo1.png"
  },
  {
    id: "musicorg1",
    name: "Global Music Festivals",
    description: "World-class music event management",
    logo: "https://example.com/logo2.png"
  },
  {
    id: "foodorg1",
    name: "Culinary Arts Society",
    description: "Premium food and beverage events",
    logo: "https://example.com/logo3.png"
  }
];