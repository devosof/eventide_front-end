export interface Event {
  id: string
  title: string
  description: string
  date: Date
  location: string
  organizerId: string
  organizationId: string
  price: number
  capacity: number
  imageUrl: string
  categories: string[]
  tags: string[]
  schedule: EventScheduleItem[]
  // Suggested additional fields for enhanced UX
  status?: "upcoming" | "ongoing" | "completed" | "cancelled"
  attendeeCount?: number
  isFavorite?: boolean
  rating?: number
  remainingSpots?: number
  organizer?: { name: string; avatar?: string }
  isSoldOut?: boolean
}

export interface EventScheduleItem {
  time: string
  activity: string
}