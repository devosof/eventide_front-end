// src/pages/EventDetails.tsx
import { useParams } from 'react-router-dom';

const EventDetails = () => {
  const { id } = useParams();
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold">Event Details</h1>
      <p className="mt-4 text-gray-600">Showing details for event ID: {id}</p>
    </div>
  );
};

export default EventDetails;