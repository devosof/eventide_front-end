// src/pages/Dashboard.tsx
const Dashboard = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold">Dashboard</h1>
      <p className="mt-4 text-gray-600">User/Organizer dashboard</p>
    </div>
  );
};

export default Dashboard;
