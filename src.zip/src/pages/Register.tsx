// src/pages/Register.tsx
const Register = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold">Register</h1>
      <p className="mt-4 text-gray-600">Registration form will go here</p>
    </div>
  );
};

export default Register;